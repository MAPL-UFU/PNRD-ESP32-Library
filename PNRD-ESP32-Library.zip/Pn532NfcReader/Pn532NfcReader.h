#ifndef PN532_NFC_READER_H

#define PN532_NFC_READER_H

#include <Arduino.h> 
#include "Pnrd.h"

#include <PN532.h>
#include <NfcAdapter.h>

/*
 * This file is part of PnrdArduinoLibrary
 * Developed by MAPL laboratory 
 * UFU - Federal University Of Uberlândia - Brazil  
 *
 * Pn532NfcReader module
 * Purpose: implementation of an Arduino RFID reader for the library usage.
 *
 * @author Carlos E. A. Silva
 * @version 1.0 14/03/18 
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */ 

/**
 * Implementation of a reader for the ElectroHouse's RFID reader PN532 NFC V3. 
 */
class Pn532NfcReader: public Reader{
	private:	
		NfcAdapter* nfcAdapter;	
		ReadError getInformation(byte* payload, Pnrd* pnrd);
		WriteError setInformation(byte* payload, Pnrd* pnrd);
	
	public:
		/**
		 * Prepares the reader to read and write tags.
		 */
		void initialize();	
		
		/**
		 * Sets the Nfc Adapter of the reader.
		 *
		 * @param adapter Nfc adapter to be used.
		 */
		Pn532NfcReader(NfcAdapter* adapter);
	
		/**
		 * Function that implements the reading of a tag.
		 *
		 * @param[out] The Pnrd instance where the information in the tag shall be stored if the reading is succesful.
		 * @return The read error, if any occurred.	
		 */
		ReadError  read(Pnrd* pnrd);
		
		/**
		 * Function that implements the writing of a tag.
		 *
		 * @param[in] The Pnrd instance where to get the information to be stored in the tag.
		 * @return The write error, if any occurred.	
		 */
		WriteError write(Pnrd* pnrd);
};
#endif